# Parental Care

A consent-based Android parent/child device-management application.

## Production architecture

**Supabase** is the backend of record:

- Supabase Auth
- PostgreSQL
- Row Level Security
- RPC/transactional database logic
- Private Supabase Storage
- Supabase Realtime
- Supabase Edge Functions

**Firebase is used only for FCM.**

## Screenshot flow

```text
Parent
  ↓
Supabase screenshot request
  ↓
Supabase Edge Function
  ↓
Firebase FCM
  ↓
Child request UI
  ↓
Child explicitly taps Take Screenshot
  ↓
Android Accessibility screenshot API
  ↓
AES-256-GCM encryption
  ↓
RSA-OAEP key wrapping to parent's public key
  ↓
Private Supabase Storage
  ↓
Parent downloads encrypted blob
  ↓
Android Keystore private key
  ↓
Decrypt + display
```

The production capture path does **not** use MediaProjection.

## Repository layout

```text
app-parent/        Parent Android app
app-child/         Child Android app
core/common/       Shared models/utilities
core/design/       Shared Compose design system
core/data/         Supabase repositories + Storage
core/security/     Pairing + encryption + Keystore
core/notifications FCM payload/service layer
supabase/          PostgreSQL migrations + Edge Functions
docs/              Architecture, security and build documentation
```

## Supabase setup

Run the migrations in order:

```text
supabase/migrations/001_initial_schema.sql
supabase/migrations/002_retention_sweep_pg_cron.sql
```

If upgrading an existing database from an older version, also run:

```text
supabase/migrations/003_production_hardening.sql
```

The screenshot bucket must remain **private**.

## FCM Edge Function

Deploy:

```text
supabase/functions/send-screenshot-request
```

Configure the server-side secrets:

```text
SUPABASE_SERVICE_ROLE_KEY
FIREBASE_SERVICE_ACCOUNT_JSON
```

Never place either secret in an APK.

## Android configuration

Supabase URL and anon key are in:

```text
core/common/src/main/res/values/strings.xml
```

Firebase Messaging project values are in each app's resource strings. Firebase is not used for Auth, Firestore or Storage.

## Build

JDK 17 is required.

```bash
./gradlew :app-parent:assembleDebug
./gradlew :app-child:assembleDebug
```

Release signing uses environment variables; never commit a release keystore.

See:

- `docs/ARCHITECTURE.md`
- `docs/SECURITY.md`
- `docs/BUILD.md`
- `supabase/README.md`

## Important

The project intentionally does not implement keylogging, message/SMS reading, credential theft, microphone/camera recording, root exploits or permission bypasses. Accessibility is retained only for the existing screenshot capability and the child-facing request/monitoring flow remains explicit.
