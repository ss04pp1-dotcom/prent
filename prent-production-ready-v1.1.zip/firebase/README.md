# Firebase usage

Firebase is used **only for Firebase Cloud Messaging (FCM)** in Parental Care.

Authentication, PostgreSQL, Row Level Security, Storage, pairing, and screenshot metadata are handled by Supabase.

The Android apps initialize Firebase Messaging explicitly from the app's Firebase configuration resources; the Google Services Gradle plugin is not required.
