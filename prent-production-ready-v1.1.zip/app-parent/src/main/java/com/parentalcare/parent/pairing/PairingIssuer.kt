package com.parentalcare.parent.pairing

import com.parentalcare.core.data.pairing.PairingRepository
import com.parentalcare.core.security.pairing.PairingSerializer
import com.parentalcare.core.security.pairing.PairingToken
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Orchestrates the parent-side pairing flow:
 *   1. Issue a one-time pairing token via [PairingRepository].
 *   2. Serialize it into a QR-scannable string via [PairingSerializer].
 *   3. Hand the string to [com.parentalcare.parent.qr.QrCodeGenerator]
 *      for rendering.
 *
 * Tokens expire in 2 minutes. Always regenerate before showing the QR if
 * the previous token has expired.
 */
@Singleton
class PairingIssuer @Inject constructor(
    private val pairingRepo: PairingRepository,
    private val serializer: PairingSerializer,
) {

    suspend fun issueForQr(
        familyId: String,
        parentDisplayName: String,
        parentEmail: String,
    ): Pair<String, PairingToken> {
        val token = pairingRepo
            .issuePairingToken(familyId, parentDisplayName, parentEmail)
            .getOrNull()
            ?: throw IllegalStateException("failed to issue pairing token")
        return serializer.encode(token) to token
    }
}
