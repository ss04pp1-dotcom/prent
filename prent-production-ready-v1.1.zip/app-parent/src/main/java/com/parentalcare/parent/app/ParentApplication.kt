package com.parentalcare.parent.app

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.parentalcare.core.notifications.NotificationChannelInitializer
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

@HiltAndroidApp
class ParentApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        if (FirebaseApp.getApps(this).isEmpty()) {
            FirebaseApp.initializeApp(this, FirebaseOptions.Builder()
                .setProjectId(getString(com.parentalcare.parent.R.string.firebase_project_id))
                .setApplicationId(getString(com.parentalcare.parent.R.string.firebase_application_id))
                .setApiKey(getString(com.parentalcare.parent.R.string.firebase_api_key))
                .setGcmSenderId(getString(com.parentalcare.parent.R.string.firebase_sender_id))
                .setStorageBucket(getString(com.parentalcare.parent.R.string.firebase_storage_bucket))
                .build())
        }
        if (com.parentalcare.parent.BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
        NotificationChannelInitializer.initialize(this)
    }
}
