package com.parentalcare.child.ui.screen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.parentalcare.child.pipeline.IncomingRequestHandler
import com.parentalcare.core.data.model.ScreenshotRequestDoc
import com.parentalcare.core.data.request.ScreenshotRequestRepository
import com.parentalcare.core.notifications.SafePayload
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RequestViewModel @Inject constructor(
    private val incomingRequestHandler: IncomingRequestHandler,
    private val requestRepository: ScreenshotRequestRepository
) : ViewModel() {

    val activeRequest: StateFlow<ScreenshotRequestDoc?> = incomingRequestHandler.active

    fun acceptRequest() {
        // Keep the request active until capture succeeds or the user cancels.
        // CaptureViewModel needs the request to upload and transition it atomically.
    }

    fun cancelRequest() {
        viewModelScope.launch {
            activeRequest.value?.let { req ->
                requestRepository.updateStatus(req, "CANCELLED", "Child cancelled the request.")
                incomingRequestHandler.handleCancelled(SafePayload(type = "CANCEL"))
            }
        }
    }
}
