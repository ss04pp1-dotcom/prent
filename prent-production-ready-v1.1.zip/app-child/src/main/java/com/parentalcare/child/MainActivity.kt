package com.parentalcare.child

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.parentalcare.child.nav.ChildRootNav
import com.parentalcare.core.design.theme.ParentalCareChildTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val light = Color(0xFFF5F6FA)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(light.toArgb(), light.toArgb()),
            navigationBarStyle = SystemBarStyle.light(light.toArgb(), light.toArgb()),
        )
        setContent {
            ParentalCareChildTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = light) {
                    ChildRootNav()
                }
            }
        }
    }


}
