package com.parentalcare.child.ui.screen
import com.parentalcare.core.common.result.userFriendlyMessage

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.parentalcare.child.mediaprojection.ScreenCaptureManager
import com.parentalcare.child.pipeline.IncomingRequestHandler
import com.parentalcare.core.data.request.ScreenshotRequestRepository
import com.parentalcare.core.data.prefs.ChildPreferences
import com.parentalcare.core.data.screenshot.ScreenshotRepository
import com.parentalcare.core.common.result.Result
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

@HiltViewModel
class CaptureViewModel @Inject constructor(
    private val screenCaptureManager: ScreenCaptureManager,
    private val incomingRequestHandler: IncomingRequestHandler,
    private val requestRepository: ScreenshotRequestRepository,
    private val screenshotRepository: ScreenshotRepository,
    private val childPreferences: ChildPreferences
) : ViewModel() {

    private val _isCapturing = MutableStateFlow(false)
    private val _captureSucceeded = MutableStateFlow(false)
    val captureSucceeded: StateFlow<Boolean> = _captureSucceeded.asStateFlow()
    val isCapturing: StateFlow<Boolean> = _isCapturing.asStateFlow()

    private val _isServiceReady = MutableStateFlow(false)
    val isServiceReady: StateFlow<Boolean> = _isServiceReady.asStateFlow()

    init {
        observeServiceReadiness()
    }

    private fun observeServiceReadiness() {
        viewModelScope.launch {
            screenCaptureManager.isAccessibilityServiceReady
                .collect { ready ->
                    _isServiceReady.value = ready
                }
        }
    }

    fun manualCapture() {
        if (_isCapturing.value) return
        viewModelScope.launch {
            _isCapturing.value = true
            _captureSucceeded.value = false
            val req = incomingRequestHandler.active.value
            if (req == null) {
                Timber.w("Manual capture: no active request")
                _isCapturing.value = false
                return@launch
            }

            requestRepository.updateStatus(req, "PROCESSING")

            val result = screenCaptureManager.captureSilently()
            if (result is Result.Success) {
                val bitmap = result.data
                val upload = screenshotRepository.uploadCaptured(bitmap, req, childPreferences.parentEncryptionPublicKey.first())
                if (upload is Result.Failure) {
                    requestRepository.updateStatus(req, "FAILED", upload.error.userFriendlyMessage)
                    _isCapturing.value = false
                    return@launch
                }
                val status = requestRepository.updateStatus(req, "UPLOADED")
                if (status is Result.Failure) {
                    _isCapturing.value = false
                    return@launch
                }
                incomingRequestHandler.handleCancelled(com.parentalcare.core.notifications.SafePayload(type="CANCEL"))
                _captureSucceeded.value = true
                _isCapturing.value = false
            } else if (result is Result.Failure) {
                Timber.e("Failed to capture silently (manual): ${result.error}")
                requestRepository.updateStatus(req, "FAILED", result.error.userFriendlyMessage)
                incomingRequestHandler.handleCancelled(com.parentalcare.core.notifications.SafePayload(type="CANCEL"))
                _isCapturing.value = false
            }
        }
    }
}
