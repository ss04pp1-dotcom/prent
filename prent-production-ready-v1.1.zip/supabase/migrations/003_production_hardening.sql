-- Production hardening / upgrade migration for databases created with 001/002.
-- The application stores timestamps as epoch milliseconds (BIGINT).

BEGIN;

-- Timestamp compatibility ---------------------------------------------------
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN SELECT table_name, column_name
           FROM information_schema.columns
           WHERE table_schema='public'
             AND column_name IN ('created_at','updated_at','added_at','paired_at','last_seen_at',
                                 'last_screenshot_at','expires_at','completed_at','captured_at',
                                 'delivered_at','viewed_at','deleted_at','retention_expires_at','consumed_at')
             AND data_type='timestamp with time zone'
  LOOP
    EXECUTE format(
      'ALTER TABLE public.%I ALTER COLUMN %I TYPE BIGINT USING (extract(epoch from %I) * 1000)::bigint',
      r.table_name, r.column_name, r.column_name
    );
  END LOOP;
END $$;

-- Child pairing metadata ----------------------------------------------------
ALTER TABLE public.members ADD COLUMN IF NOT EXISTS parent_user_id UUID REFERENCES public.users(id) ON DELETE CASCADE;
ALTER TABLE public.pairing_tokens ADD COLUMN IF NOT EXISTS parent_encryption_public_key TEXT;

-- Anonymous child profiles must be able to exist before pairing.
ALTER TABLE public.users ALTER COLUMN email DROP NOT NULL;

-- Existing activity rows may have the old shape; preserve the table but add
-- fields used by the Android model. New installs use the final shape in 001.
ALTER TABLE public.activity_log ADD COLUMN IF NOT EXISTS actor_type TEXT NOT NULL DEFAULT 'SYSTEM';
ALTER TABLE public.activity_log ADD COLUMN IF NOT EXISTS request_id TEXT;
ALTER TABLE public.activity_log ADD COLUMN IF NOT EXISTS message TEXT NOT NULL DEFAULT '';
ALTER TABLE public.activity_log ALTER COLUMN actor_user_id TYPE TEXT USING actor_user_id::text;
ALTER TABLE public.activity_log ALTER COLUMN actor_device_id TYPE TEXT USING actor_device_id::text;
ALTER TABLE public.activity_log ALTER COLUMN id TYPE TEXT USING id::text;

-- Remove old policies so the corrected versions below are authoritative.
DROP POLICY IF EXISTS "Device can read own record" ON public.devices;
DROP POLICY IF EXISTS "Device can create own record" ON public.devices;
DROP POLICY IF EXISTS "Owners can update devices" ON public.devices;
DROP POLICY IF EXISTS "Device can read own pending requests" ON public.screenshot_requests;
DROP POLICY IF EXISTS "Valid status transitions" ON public.screenshot_requests;
DROP POLICY IF EXISTS "Device can upload screenshots" ON public.screenshots;
DROP POLICY IF EXISTS "Child can read own membership" ON public.members;
DROP POLICY IF EXISTS "Child can create own membership" ON public.members;
DROP POLICY IF EXISTS "Users can bootstrap child role" ON public.users;

CREATE POLICY "Users can bootstrap child role" ON public.users
FOR UPDATE USING (auth.uid() = id AND family_id IS NULL)
WITH CHECK (auth.uid() = id AND role = 'CHILD' AND family_id IS NULL);

CREATE POLICY "Child can read own membership" ON public.members
FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Child can create own membership" ON public.members
FOR INSERT WITH CHECK (
  user_id = auth.uid()
  AND role = 'CHILD'
  AND EXISTS (
    SELECT 1 FROM public.families f
    WHERE f.id = members.family_id
      AND f.parent_user_id = members.parent_user_id
  )
  AND NOT EXISTS (
    SELECT 1 FROM public.members m
    WHERE m.family_id = members.family_id AND m.user_id = auth.uid()
  )
);

CREATE POLICY "Device can read own record" ON public.devices
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.members m
    WHERE m.id = devices.owner_member_id AND m.user_id = auth.uid()
  )
);

CREATE POLICY "Device can create own record" ON public.devices
FOR INSERT WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.members m
    WHERE m.id = devices.owner_member_id
      AND m.user_id = auth.uid()
      AND m.family_id = devices.family_id
      AND m.role = 'CHILD'
  )
);

CREATE POLICY "Owners can update devices" ON public.devices
FOR UPDATE USING (
  EXISTS (SELECT 1 FROM public.families f WHERE f.id=devices.family_id AND f.parent_user_id=auth.uid())
  OR EXISTS (SELECT 1 FROM public.members m WHERE m.id=devices.owner_member_id AND m.user_id=auth.uid())
)
WITH CHECK (
  family_id = (SELECT d.family_id FROM public.devices d WHERE d.id=devices.id)
  AND owner_member_id = (SELECT d.owner_member_id FROM public.devices d WHERE d.id=devices.id)
);

CREATE POLICY "Device can read own pending requests" ON public.screenshot_requests
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.devices d
    JOIN public.members m ON m.id=d.owner_member_id
    WHERE d.id=screenshot_requests.child_device_id
      AND d.family_id=screenshot_requests.family_id
      AND m.user_id=auth.uid()
  )
  AND expires_at > (extract(epoch from clock_timestamp())*1000)::bigint
);

CREATE OR REPLACE FUNCTION public.enforce_screenshot_request_transition()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.id<>OLD.id OR NEW.family_id<>OLD.family_id OR NEW.parent_user_id<>OLD.parent_user_id
     OR NEW.child_device_id<>OLD.child_device_id OR NEW.nonce<>OLD.nonce
     OR NEW.created_at<>OLD.created_at OR NEW.expires_at<>OLD.expires_at THEN
    RAISE EXCEPTION 'request identity and timing fields are immutable';
  END IF;
  IF NEW.status<>OLD.status THEN
    IF OLD.status='REQUESTED' AND NEW.status NOT IN ('PROCESSING','CANCELLED','EXPIRED','FAILED') THEN RAISE EXCEPTION 'invalid request transition'; END IF;
    IF OLD.status='PROCESSING' AND NEW.status NOT IN ('UPLOADED','FAILED','EXPIRED','CANCELLED') THEN RAISE EXCEPTION 'invalid request transition'; END IF;
    IF OLD.status='UPLOADED' AND NEW.status<>'DELIVERED' THEN RAISE EXCEPTION 'invalid request transition'; END IF;
    IF OLD.status IN ('DELIVERED','CANCELLED','EXPIRED','FAILED') THEN RAISE EXCEPTION 'request is terminal'; END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path=public;
DROP TRIGGER IF EXISTS enforce_screenshot_request_transition ON public.screenshot_requests;
CREATE TRIGGER enforce_screenshot_request_transition
BEFORE UPDATE ON public.screenshot_requests
FOR EACH ROW EXECUTE FUNCTION public.enforce_screenshot_request_transition();

CREATE POLICY "Valid status transitions" ON public.screenshot_requests
FOR UPDATE USING (
  EXISTS (SELECT 1 FROM public.families f WHERE f.id=screenshot_requests.family_id AND f.parent_user_id=auth.uid())
  OR EXISTS (
    SELECT 1 FROM public.devices d JOIN public.members m ON m.id=d.owner_member_id
    WHERE d.id=screenshot_requests.child_device_id AND m.user_id=auth.uid()
  )
)
WITH CHECK (
  family_id=(SELECT sr.family_id FROM public.screenshot_requests sr WHERE sr.id=screenshot_requests.id)
  AND child_device_id=(SELECT sr.child_device_id FROM public.screenshot_requests sr WHERE sr.id=screenshot_requests.id)
  AND parent_user_id=(SELECT sr.parent_user_id FROM public.screenshot_requests sr WHERE sr.id=screenshot_requests.id)
  AND nonce=(SELECT sr.nonce FROM public.screenshot_requests sr WHERE sr.id=screenshot_requests.id)
  AND expires_at=(SELECT sr.expires_at FROM public.screenshot_requests sr WHERE sr.id=screenshot_requests.id)
);

CREATE POLICY "Device can upload screenshots" ON public.screenshots
FOR INSERT WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.devices d JOIN public.members m ON m.id=d.owner_member_id
    WHERE d.id=screenshots.child_device_id AND d.family_id=screenshots.family_id AND m.user_id=auth.uid()
  )
  AND EXISTS (
    SELECT 1 FROM public.screenshot_requests sr
    WHERE sr.id=screenshots.request_id AND sr.family_id=screenshots.family_id
      AND sr.parent_user_id=screenshots.parent_user_id AND sr.status='PROCESSING'
  )
  AND storage_path ~ '^families/[^/]+/screenshots/[^/]+/[^/]+\.enc$'
  AND retention_expires_at > (extract(epoch from clock_timestamp())*1000)::bigint
);

-- One screenshot per request makes retries idempotent.
CREATE UNIQUE INDEX IF NOT EXISTS idx_screenshots_request_unique ON public.screenshots(request_id);

-- Private storage: child can upload only to its own device path; parent can read/delete family objects.
DROP POLICY IF EXISTS "Device can upload screenshots" ON storage.objects;
CREATE POLICY "Device can upload screenshots" ON storage.objects
FOR INSERT WITH CHECK (
  bucket_id='screenshots'
  AND (storage.foldername(name))[1]='families'
  AND (storage.foldername(name))[3]='screenshots'
  AND EXISTS (
    SELECT 1 FROM public.devices d JOIN public.members m ON m.id=d.owner_member_id
    WHERE d.id::text=(storage.foldername(name))[4]
      AND d.family_id::text=(storage.foldername(name))[2]
      AND m.user_id=auth.uid()
  )
  AND name ~ '^families/[^/]+/screenshots/[^/]+/[^/]+\.enc$'
);

-- Fix the retention sweep function for BIGINT timestamps.
CREATE OR REPLACE FUNCTION public.enqueue_expired_screenshots()
RETURNS void AS $$
BEGIN
  UPDATE public.screenshots
  SET deleted_at=(extract(epoch from clock_timestamp())*1000)::bigint
  WHERE retention_expires_at < (extract(epoch from clock_timestamp())*1000)::bigint
    AND deleted_at IS NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path=public;

COMMIT;
