# Supabase production backend

Run migrations in this order:

1. `migrations/001_initial_schema.sql`
2. `migrations/002_retention_sweep_pg_cron.sql`
3. `migrations/003_production_hardening.sql` when upgrading an existing database created from older project versions.

The screenshot bucket is private. Screenshot ciphertext is stored only in Supabase Storage; the `screenshots` table stores metadata, IV and the RSA-wrapped AES content key.

Firebase is used only for FCM delivery.
