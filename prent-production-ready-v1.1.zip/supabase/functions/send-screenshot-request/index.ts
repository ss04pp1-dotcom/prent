import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { JWT } from "npm:google-auth-library@9";

Deno.serve(async (req) => {
  try {
    const auth = req.headers.get("Authorization");
    if (!auth) return new Response("Unauthorized", { status: 401 });
    const body = await req.json();
    const requestId = body?.requestId;
    if (!requestId) return new Response("requestId required", { status: 400 });

    const url = Deno.env.get("SUPABASE_URL")!;
    const anon = Deno.env.get("SUPABASE_ANON_KEY")!;
    const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const sb = createClient(url, anon, { global: { headers: { Authorization: auth } } });
    const { data: { user } } = await sb.auth.getUser();
    if (!user) return new Response("Unauthorized", { status: 401 });

    const admin = createClient(url, service);
    const { data: request, error: re } = await admin.from("screenshot_requests").select("id,family_id,parent_user_id,child_device_id,status,expires_at").eq("id", requestId).single();
    if (re || !request || request.parent_user_id !== user.id || request.status !== "REQUESTED") return new Response("Forbidden", { status: 403 });
    if (request.expires_at <= Date.now()) return new Response("Expired", { status: 409 });

    const { data: device, error: de } = await admin.from("devices").select("fcm_token").eq("id", request.child_device_id).eq("family_id", request.family_id).single();
    if (de || !device?.fcm_token) return new Response("Device has no FCM token", { status: 409 });

    const raw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON");
    if (!raw) return new Response("FCM server credentials not configured", { status: 500 });
    const serviceAccount = JSON.parse(raw);
    const jwt = new JWT({ email: serviceAccount.client_email, key: serviceAccount.private_key, scopes: ["https://www.googleapis.com/auth/firebase.messaging"] });
    const access = await jwt.authorize();
    const projectId = serviceAccount.project_id;
    const fcm = await fetch(`https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`, {
      method: "POST",
      headers: { Authorization: `Bearer ${access.access_token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ message: { token: device.fcm_token, data: { type: "SCREENSHOT_REQUEST", requestId: request.id, familyId: request.family_id, childDeviceId: request.child_device_id, ts: String(Date.now()) } } })
    });
    if (!fcm.ok) return new Response(await fcm.text(), { status: 502 });
    return Response.json({ ok: true });
  } catch (e) {
    console.error(e);
    return new Response("Internal error", { status: 500 });
  }
});
