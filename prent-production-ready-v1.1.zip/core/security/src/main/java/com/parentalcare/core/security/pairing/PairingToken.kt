package com.parentalcare.core.security.pairing

import com.parentalcare.core.common.util.SecureTokenGenerator
import com.parentalcare.core.security.crypto.KeyExchangeManager
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName
import java.security.MessageDigest

/**
 * One-time pairing token. Issued by the parent app, scanned via QR by the
 * child app. Single-use, short TTL.
 *
 * The QR code carries a JSON serialization of this record (no long-term
 * secrets — only a short-lived opaque token). The child sends the token back
 * to the Supabase `consume_pairing_token` RPC, which looks it up by
 * `token_id` in the `pairing_tokens` table to claim the pairing.
 *
 * Wire format on the QR code: base32(payloadJson) — short enough to fit a
 * standard QR (~120 chars), short TTL = 2 minutes.
 */
@Serializable
data class PairingToken(
    @SerialName("token_id") val tokenId: String,
    val opaque: String,
    @SerialName("family_id") val familyId: String,
    @SerialName("parent_user_id") val parentUserId: String,
    @SerialName("parent_display_name") val parentDisplayName: String,
    @SerialName("parent_email") val parentEmail: String,
    @SerialName("parent_encryption_public_key") val parentEncryptionPublicKey: String? = null,
    @SerialName("created_at") val createdAt: Long,
    @SerialName("expires_at") val expiresAt: Long,
    val nonce: String,
    /** true once the child has claimed it. */
    @SerialName("is_consumed") val isConsumed: Boolean = false,
    @SerialName("consumed_by_device_id") val consumedByDeviceId: String? = null,
) {
    val isExpired: Boolean get() = System.currentTimeMillis() > expiresAt

    fun verify(other: PairingToken): Boolean {
        // Constant-time comparison for all secret fields to prevent timing attacks.
        return constantTimeEquals(tokenId, other.tokenId)
            && constantTimeEquals(opaque, other.opaque)
            && constantTimeEquals(nonce, other.nonce)
    }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var diff = 0
        for (i in a.indices) {
            diff = diff or (a[i].code xor b[i].code)
        }
        return diff == 0
    }
}

class PairingTokenFactory(private val keyExchange: KeyExchangeManager? = null) {

    fun issue(
        familyId: String,
        parentUserId: String,
        parentDisplayName: String,
        parentEmail: String,
        ttlSeconds: Long = 120,
        now: Long = System.currentTimeMillis(),
    ): PairingToken {
        val tokenId = SecureTokenGenerator.generateOpaqueToken()
        val opaque = SecureTokenGenerator.generateOpaqueToken()
        val nonce = SecureTokenGenerator.generateNonce()
        return PairingToken(
            tokenId = tokenId,
            opaque = opaque,
            familyId = familyId,
            parentUserId = parentUserId,
            parentDisplayName = parentDisplayName,
            parentEmail = parentEmail,
            parentEncryptionPublicKey = keyExchange?.publicKeyBase64(),
            createdAt = now,
            expiresAt = now + ttlSeconds * 1000,
            nonce = nonce,
        )
    }

    /** SHA-256 of the opaque token, checked against `pairing_tokens.opaque` for lookup. */
    fun hashKey(token: PairingToken): String {
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(token.opaque.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
