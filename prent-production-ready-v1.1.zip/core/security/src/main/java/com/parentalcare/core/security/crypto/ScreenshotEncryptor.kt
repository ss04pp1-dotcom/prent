package com.parentalcare.core.security.crypto

import android.util.Base64
import com.parentalcare.core.security.keystore.KeystoreManager
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Application-layer screenshot encryption using AES-GCM (96-bit IV, 128-bit auth tag).
 *
 * Design:
 *   - Each screenshot is encrypted with a fresh 256-bit content key.
 *   - The content key is wrapped (encrypted) by a Keystore-backed AES-GCM key.
 *   - Wrapped key + IV travel alongside the ciphertext in the Supabase
 *     `screenshots` row / Supabase Storage object metadata.
 *   - The Keystore master key never leaves the secure enclave.
 *
 * Threat model this defends against:
 *   - A malicious user reading another family's screenshot URL — the ciphertext
 *     is useless without the wrapped key + Keystore key on an authorized device.
 *
 * What this does NOT defend against:
 *   - A parent's own device compromise — the parent can decrypt their own
 *     screenshots; that is the intended behavior.
 *
 * Wire format (base64-encoded segments joined by '.'):
 *   iv . wrappedKey . ciphertext
 *
 * Logging policy: NEVER log the IV, wrapped key, or ciphertext bytes.
 */
class ScreenshotEncryptor(
    private val keystore: KeystoreManager,
    private val keyExchange: KeyExchangeManager,
) {

    /** Returns base64(iv) . base64(wrappedKey) . base64(ciphertext). */
    fun encrypt(plaintext: ByteArray, familyId: String): EncryptedPayload {
        val contentKey = ByteArray(KEY_SIZE_BYTES).also { SECURE_RANDOM.nextBytes(it) }
        val iv = ByteArray(IV_SIZE_BYTES).also { SECURE_RANDOM.nextBytes(it) }

        // Encrypt screenshot with fresh content key.
        val cipher = Cipher.getInstance(TRANSFORM).apply {
            init(Cipher.ENCRYPT_MODE, SecretKeySpec(contentKey, "AES"), GCMParameterSpec(GCM_TAG_BITS, iv))
        }
        val ciphertext = cipher.doFinal(plaintext)

        // Wrap content key with Keystore-backed master key.
        val wrapped = keystore.wrap(contentKey, familyId)

        return EncryptedPayload(
            iv = Base64.encodeToString(iv, BASE64_FLAGS),
            wrappedKey = wrapped,
            ciphertext = Base64.encodeToString(ciphertext, BASE64_FLAGS),
        )
    }

    fun encryptForParent(plaintext: ByteArray, familyId: String, parentPublicKey: String): EncryptedPayload {
        val contentKey = ByteArray(KEY_SIZE_BYTES).also { SECURE_RANDOM.nextBytes(it) }
        val iv = ByteArray(IV_SIZE_BYTES).also { SECURE_RANDOM.nextBytes(it) }
        val cipher = Cipher.getInstance(TRANSFORM).apply {
            init(Cipher.ENCRYPT_MODE, SecretKeySpec(contentKey, "AES"), GCMParameterSpec(GCM_TAG_BITS, iv))
        }
        val ciphertext = cipher.doFinal(plaintext)
        return EncryptedPayload(
            iv = Base64.encodeToString(iv, BASE64_FLAGS),
            wrappedKey = keyExchange.wrapForPublicKey(contentKey, parentPublicKey),
            ciphertext = Base64.encodeToString(ciphertext, BASE64_FLAGS),
        )
    }

    fun decrypt(payload: EncryptedPayload, familyId: String): ByteArray {
        val contentKey = unwrapContentKey(payload.wrappedKey, familyId)
        val iv = Base64.decode(payload.iv, BASE64_FLAGS)
        val ciphertext = Base64.decode(payload.ciphertext, BASE64_FLAGS)

        val cipher = Cipher.getInstance(TRANSFORM).apply {
            init(Cipher.DECRYPT_MODE, SecretKeySpec(contentKey, "AES"), GCMParameterSpec(GCM_TAG_BITS, iv))
        }
        return cipher.doFinal(ciphertext)
    }

    /**
     * Decrypts using the actual downloaded encrypted content from Storage
     * instead of the base64 payload (for production use where .enc file is source of truth).
     */
    fun decryptWithContent(payload: EncryptedPayload, familyId: String, encryptedContent: ByteArray): ByteArray {
        val contentKey = unwrapContentKey(payload.wrappedKey, familyId)
        val iv = Base64.decode(payload.iv, BASE64_FLAGS)

        val cipher = Cipher.getInstance(TRANSFORM).apply {
            init(Cipher.DECRYPT_MODE, SecretKeySpec(contentKey, "AES"), GCMParameterSpec(GCM_TAG_BITS, iv))
        }
        return cipher.doFinal(encryptedContent)
    }

    private fun unwrapContentKey(wrappedKey: String, familyId: String): ByteArray =
        if (wrappedKey.startsWith("RSA1:")) keyExchange.unwrapForCurrentDevice(wrappedKey)
        else keystore.unwrap(wrappedKey, familyId)

    private companion object {
        const val KEY_SIZE_BYTES = 32 // 256-bit
        const val IV_SIZE_BYTES = 12  // 96-bit GCM IV
        const val GCM_TAG_BITS = 128
        const val TRANSFORM = "AES/GCM/NoPadding"
        const val BASE64_FLAGS = Base64.NO_WRAP
        val SECURE_RANDOM: SecureRandom = SecureRandom()
        const val TAG = "PC.ScreenshotEncryptor"
    }
}

/**
 * Carrier for encrypted bytes. The two string fields are serialized into
 * Supabase `screenshots` row; the ciphertext is uploaded to Supabase Storage as a `.enc` blob.
 */
data class EncryptedPayload(
    val iv: String,
    val wrappedKey: String, // base64
    val ciphertext: String,  // base64 — only used in tests; production uses bytes
)
