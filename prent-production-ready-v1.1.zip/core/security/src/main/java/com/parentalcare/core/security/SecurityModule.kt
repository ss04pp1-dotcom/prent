package com.parentalcare.core.security

import com.parentalcare.core.security.crypto.ScreenshotEncryptor
import com.parentalcare.core.security.crypto.KeyExchangeManager
import com.parentalcare.core.security.keystore.KeystoreManager
import com.parentalcare.core.security.pairing.PairingTokenFactory
import com.parentalcare.core.security.pairing.PairingSerializer
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object SecurityModule {

    @Provides @Singleton
    fun provideKeystoreManager(@ApplicationContext ctx: android.content.Context): KeystoreManager =
        KeystoreManager(ctx)

    @Provides @Singleton
    fun provideKeyExchangeManager(): KeyExchangeManager =
        KeyExchangeManager()

    @Provides @Singleton
    fun provideEncryptor(ks: KeystoreManager, keyExchange: KeyExchangeManager): ScreenshotEncryptor =
        ScreenshotEncryptor(ks, keyExchange)

    @Provides @Singleton
    fun providePairingFactory(keyExchange: KeyExchangeManager): PairingTokenFactory = PairingTokenFactory(keyExchange)

    @Provides @Singleton
    fun providePairingSerializer(): PairingSerializer = PairingSerializer()
}
