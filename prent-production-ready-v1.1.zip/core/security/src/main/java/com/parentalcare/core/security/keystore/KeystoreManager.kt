package com.parentalcare.core.security.keystore

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import timber.log.Timber
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Android Keystore-backed master-key wrapper for screenshot content keys.
 *
 * Threat model this defends against:
 *   - Screenshot ciphertext leaked from Supabase Storage (e.g. via a misconfigured
 *     security rule, an attacker sharing a family doc, or a stolen device's
 *     cached storage blob) cannot be decrypted without the wrapped key AND
 *     this Keystore key, which never leaves the secure enclave.
 *   - A different parent device on the same family account cannot read
 *     screenshots captured by another parent device — each parent device
 *     has its own Keystore master key. (For the parent to view a screenshot
 *     captured by another parent device, the screenshots are re-encrypted
 *     server-side via a Cloud Function that uses a per-family KMS key;
 *     this client wrapper only handles the "capturing parent == viewing
 *     parent" path, which is the dominant case.)
 *
 * Key derivation strategy:
 *   - One Keystore master key per familyId, named "pc_master_<sha256(familyId)[0..16]>".
 *   - Keystore master key is AES/GCM, 256-bit, no password, hardware-backed
 *     when StrongBox/TEE is available, otherwise software-backed by the
 *     AndroidKeyStore provider (still isolated from app process memory).
 *   - On wrap(): generate a fresh AES-GCM content key in-memory, encrypt
 *     the screenshot with it, then encrypt (wrap) the content key with the
 *     Keystore master key. Return base64(iv || ciphertext) of the wrapping.
 *   - On unwrap(): decrypt the wrapped key blob with the Keystore master key
 *     to recover the content key, which is then used to decrypt the
 *     screenshot ciphertext.
 *
 * Notes:
 *   - Keystore master keys are NOT exported. They live in the AndroidKeyStore
 *     and disappear when the app's data is cleared (or the keystore itself
 *     is reset).
 *   - This class is NOT responsible for the screenshot ciphertext itself
 *     (see ScreenshotEncryptor); only for the key wrapping.
 *
 * Logging policy: NEVER log the wrapped key bytes, IV, or any key material.
 */
class KeystoreManager(
    private val context: Context,
) {

    /**
     * Wraps a 256-bit content key with the Keystore master key for the
     * given family.
     *
     * Returns base64(iv || ciphertext) — a single string the caller stores
     * in the screenshot's `screenshots` row metadata.
     */
    fun wrap(contentKey: ByteArray, familyId: String): String {
        val masterKey = getOrCreateMasterKey(familyId)
        val cipher = Cipher.getInstance(TRANSFORM).apply {
            init(Cipher.ENCRYPT_MODE, masterKey)
        }
        val iv = cipher.iv
        val wrappedBytes = cipher.doFinal(contentKey)
        // Pack iv + wrapped bytes into a single blob.
        val blob = ByteArray(iv.size + wrappedBytes.size)
        System.arraycopy(iv, 0, blob, 0, iv.size)
        System.arraycopy(wrappedBytes, 0, blob, iv.size, wrappedBytes.size)
        return Base64.encodeToString(blob, Base64.NO_WRAP)
    }

    /**
     * Unwraps the content key from a base64 blob produced by [wrap].
     * Returns the raw 256-bit content key.
     */
    fun unwrap(wrapped: String, familyId: String): ByteArray {
        val masterKey = getOrCreateMasterKey(familyId)
        val blob = Base64.decode(wrapped, Base64.NO_WRAP)
        require(blob.size > IV_SIZE_BYTES) { "wrapped key blob too small" }
        val iv = blob.copyOfRange(0, IV_SIZE_BYTES)
        val ct = blob.copyOfRange(IV_SIZE_BYTES, blob.size)
        val cipher = Cipher.getInstance(TRANSFORM).apply {
            init(Cipher.DECRYPT_MODE, masterKey, GCMParameterSpec(GCM_TAG_BITS, iv))
        }
        return cipher.doFinal(ct)
    }

    /**
     * Lazily creates the Keystore master key for this family if it doesn't
     * already exist, and returns it.
     *
     * Hardware-backed when StrongBox is available; otherwise the AndroidKeyStore
     * provider still provides TEE isolation on most devices.
     */
    @Synchronized
    private fun getOrCreateMasterKey(familyId: String): SecretKey {
        val alias = masterKeyAlias(familyId)
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = ks.getKey(alias, null) as? SecretKey
        if (existing != null) return existing

        val builder = KeyGenParameterSpec.Builder(
            alias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(MASTER_KEY_SIZE_BITS)

        // Try StrongBox first if available; fall back silently to software-backed.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            try {
                builder.setIsStrongBoxBacked(true)
                val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
                gen.init(builder.build())
                return gen.generateKey()
            } catch (t: Throwable) {
                Timber.tag(TAG).w("StrongBox unavailable for family master key, falling back: %s", t.message)
                // Re-build without StrongBox.
                val fallbackBuilder = KeyGenParameterSpec.Builder(
                    alias,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(MASTER_KEY_SIZE_BITS)
                val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
                gen.init(fallbackBuilder.build())
                return gen.generateKey()
            }
        } else {
            val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            gen.init(builder.build())
            return gen.generateKey()
        }
    }

    private fun masterKeyAlias(familyId: String): String {
        // Use full SHA-256 hash to avoid collision risk.
        // Keystore aliases support up to 256 chars; "pc_master_" prefix + 64 hex chars = 74 chars.
        val sha = sha256(familyId)
        return "pc_master_$sha"
    }

    private fun sha256(input: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private companion object {
        const val TAG = "PC.Keystore"
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val TRANSFORM = "AES/GCM/NoPadding"
        const val MASTER_KEY_SIZE_BITS = 256
        const val GCM_TAG_BITS = 128
        const val IV_SIZE_BYTES = 12 // 96-bit GCM IV
    }
}
