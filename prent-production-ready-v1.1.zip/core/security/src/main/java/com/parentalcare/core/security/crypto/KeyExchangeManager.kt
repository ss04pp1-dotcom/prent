package com.parentalcare.core.security.crypto

import android.util.Base64
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.PublicKey
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher

/**
 * Device-local RSA key pair used only to wrap screenshot content keys.
 * The private key never leaves Android Keystore. The public key may be placed
 * in a short-lived pairing token so the child can encrypt a screenshot key for
 * the paired parent device.
 */
class KeyExchangeManager {
    private val alias = "pc_parent_exchange_v1"
    private val keyStoreName = "AndroidKeyStore"

    fun publicKeyBase64(): String = Base64.encodeToString(getOrCreateKeyPair().public.encoded, Base64.NO_WRAP)

    fun wrapForPublicKey(contentKey: ByteArray, publicKeyBase64: String): String {
        val publicKey = KeyFactory.getInstance("RSA").generatePublic(
            X509EncodedKeySpec(Base64.decode(publicKeyBase64, Base64.NO_WRAP))
        )
        val cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding")
        cipher.init(Cipher.ENCRYPT_MODE, publicKey)
        return "RSA1:" + Base64.encodeToString(cipher.doFinal(contentKey), Base64.NO_WRAP)
    }

    fun unwrapForCurrentDevice(wrappedKey: String): ByteArray {
        require(wrappedKey.startsWith("RSA1:")) { "Unsupported key wrapping format" }
        val cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKeyPair().private)
        return cipher.doFinal(Base64.decode(wrappedKey.removePrefix("RSA1:"), Base64.NO_WRAP))
    }

    private fun getOrCreateKeyPair(): KeyPair {
        val ks = KeyStore.getInstance(keyStoreName).apply { load(null) }
        if (ks.containsAlias(alias)) {
            return KeyPair(ks.getCertificate(alias).publicKey, ks.getKey(alias, null) as PrivateKey)
        }
        val generator = KeyPairGenerator.getInstance("RSA", keyStoreName)
        generator.initialize(
            android.security.keystore.KeyGenParameterSpec.Builder(
                alias,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                    android.security.keystore.KeyProperties.PURPOSE_DECRYPT,
            )
                .setKeySize(2048)
                .setDigests(android.security.keystore.KeyProperties.DIGEST_SHA256, android.security.keystore.KeyProperties.DIGEST_SHA512)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_RSA_OAEP)
                .build()
        )
        return generator.generateKeyPair()
    }
}
