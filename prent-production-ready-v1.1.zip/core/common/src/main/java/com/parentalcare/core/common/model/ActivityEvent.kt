package com.parentalcare.core.common.model

import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName

/**
 * Server-side timestamped envelope for safe error reporting.
 * Maps to a row in the Supabase `activity_log` table.
 */
@Serializable
data class ActivityEvent(
    @SerialName("id") val eventId: String = "",
    @SerialName("family_id") val familyId: String = "",
    @SerialName("actor_user_id") val actorId: String = "",
    @SerialName("actor_type") val actorType: ActorType = ActorType.PARENT,
    @SerialName("event_type") val type: EventType,
    @SerialName("actor_device_id") val targetDeviceId: String? = null,
    @SerialName("request_id") val requestId: String? = null,
    @SerialName("created_at") val timestamp: Long = System.currentTimeMillis(),
    /** Safe, redacted message — no PII / secrets. */
    val message: String,
)

enum class ActorType { PARENT, CHILD, SYSTEM }

enum class EventType {
    PAIRING_CREATED,
    PAIRING_REDEEMED,
    DEVICE_ONLINE,
    DEVICE_OFFLINE,
    REQUEST_SENT,
    REQUEST_RECEIVED,
    REQUEST_ACCEPTED,
    REQUEST_REJECTED,
    REQUEST_EXPIRED,
    SCREENSHOT_CAPTURED,
    SCREENSHOT_UPLOADED,
    SCREENSHOT_DELIVERED,
    SCREENSHOT_VIEWED,
    SCREENSHOT_DELETED,
    MONITORING_STARTED,
    MONITORING_STOPPED,
    DEVICE_UNPAIRED,
    AUTH_EXPIRED,
}
