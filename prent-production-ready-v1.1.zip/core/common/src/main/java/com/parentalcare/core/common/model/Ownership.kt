package com.parentalcare.core.common.model

/**
 * Multi-tenant ownership triple.
 * Embedded into every Supabase Postgres row and every Supabase Storage object's metadata.
 */
data class Ownership(
    val familyId: String,
    val parentUserId: String,
    val childDeviceId: String,
) {
    fun isValid(): Boolean =
        familyId.isNotBlank() && parentUserId.isNotBlank() && childDeviceId.isNotBlank()

    /** Supabase Storage object path: families/{familyId}/screenshots/{childDeviceId}/{screenshotId}.enc */
    fun storagePath(screenshotId: String): String =
        "families/$familyId/screenshots/$childDeviceId/$screenshotId.enc"
}
