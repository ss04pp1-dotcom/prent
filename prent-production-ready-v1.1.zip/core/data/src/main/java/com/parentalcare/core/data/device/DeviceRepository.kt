package com.parentalcare.core.data.device

import com.parentalcare.core.common.result.Result
import com.parentalcare.core.common.result.resultOf
import com.parentalcare.core.common.util.Redactor
import com.parentalcare.core.data.model.DeviceDoc
import com.parentalcare.core.data.supabase.SupabasePaths
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.postgrest.postgrest
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton
import java.util.UUID
import kotlinx.serialization.json.JsonPrimitive

@Singleton
class DeviceRepository @Inject constructor(
    private val supabase: SupabaseClient,
) {
    private val table = SupabasePaths.TABLE_DEVICES

    suspend fun redeemPairingToken(
        tokenFamilyId: String,
        tokenParentUserId: String,
        childDisplayName: String,
        deviceName: String,
        deviceModel: String,
        androidVersion: String,
        fcmToken: String,
    ): Result<DeviceDoc> = resultOf {
        val uid = supabase.auth.currentUserOrNull()?.id ?: throw IllegalStateException("not authenticated")
        require(tokenParentUserId != uid) { "child account must be different from parent account" }
        require(tokenFamilyId.isNotBlank())

        // Anonymous child accounts are bootstrapped as PARENT by the auth trigger;
        // switch the profile to CHILD before creating the family membership.
        supabase.postgrest[SupabasePaths.TABLE_USERS].update(
            mapOf(SupabasePaths.Columns.ROLE to "CHILD", SupabasePaths.Columns.DISPLAY_NAME to childDisplayName)
        ) { filter { eq(SupabasePaths.Columns.ID, uid) } }

        val deviceId = UUID.randomUUID().toString()
        val member = supabase.postgrest[SupabasePaths.TABLE_MEMBERS]
            .select { filter {
                eq(SupabasePaths.Columns.FAMILY_ID, tokenFamilyId)
                eq(SupabasePaths.Columns.USER_ID, uid)
            } }
            .decodeSingleOrNull<com.parentalcare.core.data.model.MemberDoc>()
            ?: com.parentalcare.core.data.model.MemberDoc(
                memberId = UUID.randomUUID().toString(),
                userId = uid,
                parentUserId = tokenParentUserId,
                familyId = tokenFamilyId,
                role = "CHILD",
                displayName = childDisplayName,
            ).also { supabase.postgrest[SupabasePaths.TABLE_MEMBERS].insert(it) }

        val now = System.currentTimeMillis()
        val device = DeviceDoc(
            deviceId = deviceId,
            familyId = tokenFamilyId,
            ownerMemberId = member.memberId,
            childDisplayName = childDisplayName,
            deviceName = deviceName,
            deviceModel = deviceModel,
            androidVersion = androidVersion,
            fcmToken = fcmToken,
            isOnline = true,
            pairedAt = now,
            lastSeenAt = now,
        )

        supabase.postgrest[table].insert(device)
        Timber.tag(TAG).i("device registered: devId=%s family=%s", Redactor.idPrefix(deviceId), Redactor.idPrefix(tokenFamilyId))
        device
    }

    suspend fun updateFcmToken(deviceId: String, familyId: String, token: String): Result<Unit> = resultOf {
        supabase.postgrest[table].update(
            mapOf(
                SupabasePaths.Columns.FCM_TOKEN to token,
                SupabasePaths.Columns.LAST_SEEN_AT to System.currentTimeMillis()
            )
        ) {
            filter {
                eq(SupabasePaths.Columns.DEVICE_ID, deviceId)
                eq(SupabasePaths.Columns.FAMILY_ID, familyId)
            }
        }
    }

    suspend fun setOnline(deviceId: String, familyId: String, online: Boolean): Result<Unit> = resultOf {
        supabase.postgrest[table].update(
            mapOf(
                SupabasePaths.Columns.IS_ONLINE to online,
                SupabasePaths.Columns.LAST_SEEN_AT to System.currentTimeMillis()
            )
        ) {
            filter {
                eq(SupabasePaths.Columns.DEVICE_ID, deviceId)
                eq(SupabasePaths.Columns.FAMILY_ID, familyId)
            }
        }
    }

    suspend fun setMonitoringActive(deviceId: String, familyId: String, active: Boolean): Result<Unit> = resultOf {
        supabase.postgrest[table].update(
            mapOf(SupabasePaths.Columns.IS_MONITORING_ACTIVE to active)
        ) {
            filter {
                eq(SupabasePaths.Columns.DEVICE_ID, deviceId)
                eq(SupabasePaths.Columns.FAMILY_ID, familyId)
            }
        }
    }

    suspend fun incrementCounters(
        deviceId: String,
        familyId: String,
        screenshot: Boolean = false,
        request: Boolean = false,
        lastScreenshotAt: Long? = null,
    ): Result<Unit> = resultOf {
        val device = getCurrentDevice(deviceId, familyId).getOrNull()
        if (device != null) {
            val updates = mutableMapOf<String, Any>()
            if (screenshot) updates[SupabasePaths.Columns.SCREENSHOT_COUNT] = device.screenshotCount + 1
            if (request) updates[SupabasePaths.Columns.REQUEST_COUNT] = device.requestCount + 1
            if (lastScreenshotAt != null) updates[SupabasePaths.Columns.LAST_SCREENSHOT_AT] = lastScreenshotAt
            
            if (updates.isNotEmpty()) {
                supabase.postgrest[table].update(updates) {
                    filter {
                        eq(SupabasePaths.Columns.DEVICE_ID, deviceId)
                        eq(SupabasePaths.Columns.FAMILY_ID, familyId)
                    }
                }
            }
        }
    }

    suspend fun listDevices(familyId: String): Result<List<DeviceDoc>> = resultOf {
        supabase.postgrest[table]
            .select { filter { eq(SupabasePaths.Columns.FAMILY_ID, familyId) } }
            .decodeList<DeviceDoc>()
    }

    suspend fun removeDevice(familyId: String, deviceId: String): Result<Unit> = resultOf {
        supabase.postgrest[table].delete {
            filter {
                eq(SupabasePaths.Columns.FAMILY_ID, familyId)
                eq(SupabasePaths.Columns.DEVICE_ID, deviceId)
            }
        }
    }

    suspend fun getCurrentDevice(deviceId: String, familyId: String): Result<DeviceDoc?> = resultOf {
        supabase.postgrest[table]
            .select {
                filter {
                    eq(SupabasePaths.Columns.DEVICE_ID, deviceId)
                    eq(SupabasePaths.Columns.FAMILY_ID, familyId)
                }
            }
            .decodeSingleOrNull<DeviceDoc>()
    }

    private companion object { const val TAG = "PC.SupabaseDeviceRepo" }
}
