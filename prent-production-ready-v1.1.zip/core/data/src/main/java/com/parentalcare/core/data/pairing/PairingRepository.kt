package com.parentalcare.core.data.pairing

import com.parentalcare.core.common.result.Result
import com.parentalcare.core.common.result.resultOf
import com.parentalcare.core.common.util.Redactor
import com.parentalcare.core.security.pairing.PairingToken
import com.parentalcare.core.security.pairing.PairingTokenFactory
import com.parentalcare.core.data.supabase.SupabasePaths
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.postgrest.postgrest
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PairingRepository @Inject constructor(
    private val supabase: SupabaseClient,
    private val factory: PairingTokenFactory,
) {
    private val table = SupabasePaths.TABLE_PAIRING_TOKENS

    suspend fun issuePairingToken(
        familyId: String,
        parentDisplayName: String,
        parentEmail: String,
    ): Result<PairingToken> = resultOf {
        val uid = supabase.auth.currentUserOrNull()?.id ?: throw IllegalStateException("not authenticated")
        
        val token = factory.issue(
            familyId = familyId,
            parentUserId = uid,
            parentDisplayName = parentDisplayName,
            parentEmail = parentEmail,
        )

        supabase.postgrest[table].insert(token.copy(opaque = factory.hashKey(token)))
        Timber.tag(TAG).i("pairing token issued: tokIdPrefix=%s", Redactor.idPrefix(token.tokenId))
        token
    }

    suspend fun redeemPairingToken(token: PairingToken): Result<PairingToken> = resultOf {
        val stored = supabase.postgrest[table]
            .select { filter { eq(SupabasePaths.Columns.TOKEN_ID, token.tokenId) } }
            .decodeSingleOrNull<PairingToken>()
            ?: throw IllegalStateException("pairing token not found")

        if (stored.isConsumed) throw IllegalStateException("already consumed")
        if (stored.isExpired) throw IllegalStateException("pairing token expired")
        val expectedOpaqueHash = factory.hashKey(token)
        if (stored.tokenId != token.tokenId || stored.opaque != expectedOpaqueHash || stored.nonce != token.nonce) {
            throw IllegalStateException("pairing token mismatch")
        }

        supabase.postgrest[table].update(
            mapOf(
                SupabasePaths.Columns.IS_CONSUMED to true,
                SupabasePaths.Columns.CONSUMED_BY_DEVICE_ID to factory.hashKey(token).take(16)
            )
        ) {
            filter { eq(SupabasePaths.Columns.TOKEN_ID, token.tokenId) }
        }

        Timber.tag(TAG).i("pairing token redeemed: tokIdPrefix=%s", Redactor.idPrefix(token.tokenId))
        stored
    }

    private companion object { const val TAG = "PC.SupabasePairingRepo" }
}
