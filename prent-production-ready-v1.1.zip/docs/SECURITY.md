# Security Model

## Authentication

Supabase Auth is authoritative. Parent accounts use normal authentication; child pairing uses a child-authenticated session.

## Tenant isolation

Every sensitive row carries `family_id`. RLS policies verify parent ownership or child-device membership through `members.user_id`.

## Pairing

- Token TTL: 2 minutes.
- Token is one-time use.
- Database stores a SHA-256 hash of the opaque token.
- Parent encryption public key is included in the short-lived token.
- Child membership/device creation is scoped to the token's family and parent.

## Screenshot encryption

1. Screenshot is compressed locally.
2. A fresh random AES-256 key encrypts the image using AES-GCM.
3. The AES key is wrapped with the paired parent's RSA-OAEP public key.
4. Only ciphertext is uploaded to private Storage.
5. Parent downloads ciphertext and unwraps the AES key with its Android Keystore private key.

The private key is never sent to Supabase.

## Storage

Bucket: `screenshots` — private.

Path:

```text
families/{familyId}/screenshots/{childDeviceId}/{screenshotId}.enc
```

Storage policies verify the device/family relationship for writes and parent family ownership for reads/deletes.

## Request authorization

The database rejects forged family/device IDs, immutable-field changes, invalid request transitions and cross-family access.

## Explicitly excluded capabilities

The project does not implement hidden surveillance, keylogging, message/SMS reading, credential theft, microphone/camera recording, root exploits or permission bypasses.

Accessibility is used only for the existing screenshot feature and is surfaced to the child during setup/request handling.
