# Production Build

## Requirements

- Android Studio with JDK 17
- Android SDK 35
- Gradle wrapper supplied by the repository
- A configured Supabase project
- Firebase project for FCM

## Supabase

Run:

```text
supabase/migrations/001_initial_schema.sql
supabase/migrations/002_retention_sweep_pg_cron.sql
```

For an older database created by a previous repository version, also run:

```text
supabase/migrations/003_production_hardening.sql
```

Create/verify the private `screenshots` Storage bucket.

## FCM Edge Function

Deploy `supabase/functions/send-screenshot-request` and configure:

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `FIREBASE_SERVICE_ACCOUNT_JSON`

The service-account JSON is a server-side secret and must never be placed in the Android project.

## Android Firebase

Firebase is used only for Messaging. Each app has explicit Firebase resource values. If the Firebase project changes, update the corresponding resource values with the new project ID, sender ID, API key and Android application ID.

## Debug build

```bash
./gradlew :app-parent:assembleDebug
./gradlew :app-child:assembleDebug
```

## Release build

Set:

```text
PC_RELEASE_KEYSTORE_PATH
PC_RELEASE_KEYSTORE_PASSWORD
PC_RELEASE_KEY_ALIAS
PC_RELEASE_KEY_PASSWORD
```

Then:

```bash
./gradlew :app-parent:assembleRelease
./gradlew :app-child:assembleRelease
```

Never commit a release keystore.
