# Parental Care Documentation

Parental Care is a consent-based parent/child device-management application.

## Current production stack

| Layer | Technology |
|---|---|
| UI | Jetpack Compose + Material 3 |
| Auth | Supabase Auth |
| Database | Supabase PostgreSQL + RLS |
| Storage | Private Supabase Storage |
| Realtime | Supabase Realtime |
| Notifications | Firebase Cloud Messaging only |
| Server notification bridge | Supabase Edge Function |
| Screenshot capture | Android Accessibility screenshot API |
| Encryption | AES-256-GCM + RSA-OAEP + Android Keystore |
| Pairing | Short-lived QR token |
| Minimum Android | API 26 |
| Target Android | API 35 |

## Security boundary

The Android clients use only the Supabase anon key. The Supabase service-role key and Firebase service-account credentials exist only on the server/Edge Function.

The child is shown an explicit screenshot request and must choose the capture action. The app does not implement keylogging, message reading, credential theft, microphone/camera recording, root exploits, or permission bypasses.

See `ARCHITECTURE.md`, `SECURITY.md`, and `BUILD.md`.
