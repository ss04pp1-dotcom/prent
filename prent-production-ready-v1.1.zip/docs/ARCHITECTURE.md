# Parental Care — Production Architecture

## Backend

- **Supabase Auth** — parent email/password and child anonymous account.
- **Supabase PostgreSQL + RLS** — families, members, devices, requests, screenshots, activity logs, pairing tokens.
- **Supabase Storage** — private `screenshots` bucket containing encrypted `.enc` blobs.
- **Supabase Realtime** — request/status updates and dashboard refresh.
- **Supabase Edge Function** — sends FCM screenshot-request messages without exposing Firebase server credentials to Android.
- **Firebase Cloud Messaging** — notifications only.

## Capture

The child app retains the existing Android Accessibility screenshot implementation. There is no MediaProjection capture path in the production flow.

Flow:

```text
Parent → Supabase request → Edge Function → FCM → Child
                                         ↓
                               Child sees request
                                         ↓
                              Child explicitly taps Take
                                         ↓
                              Accessibility screenshot
                                         ↓
                              JPEG compression
                                         ↓
                              AES-256-GCM encryption
                                         ↓
                              RSA-OAEP key wrapping
                                         ↓
                         private Supabase Storage + metadata
                                         ↓
                              Parent downloads .enc
                                         ↓
                           Android Keystore private key
                                         ↓
                               decrypt and display
```

## Key management

Each parent installation has an RSA-2048 key pair in Android Keystore. The public key is included in the short-lived pairing token. The child generates a fresh AES-256 content key per screenshot and wraps it to the parent's public key. The parent unwraps it using its local Keystore private key.

The private key is never uploaded.

## Request lifecycle

```text
REQUESTED → PROCESSING → UPLOADED → DELIVERED
    ├────────→ CANCELLED
    ├────────→ EXPIRED
    └────────→ FAILED
```

Database triggers reject illegal transitions and immutable-field changes.

## Storage layout

```text
families/{familyId}/screenshots/{childDeviceId}/{screenshotId}.enc
```

The bucket is private. No public download URL is used.
