#!/usr/bin/env bash
set -euo pipefail

fail=0
check_absent() {
  local pattern="$1"
  if grep -RInE "$pattern" app-parent app-child core --include='*.kt' --include='*.kts' --include='*.xml' >/tmp/pc_verify_hit 2>/dev/null; then
    echo "FAIL: stale/forbidden reference: $pattern"
    cat /tmp/pc_verify_hit
    fail=1
  fi
}

[ ! -e debug.p12 ] || { echo 'FAIL: debug.p12 still present'; fail=1; }
[ -f supabase/migrations/001_initial_schema.sql ] || { echo 'FAIL: missing initial migration'; fail=1; }
[ -f supabase/migrations/003_production_hardening.sql ] || { echo 'FAIL: missing hardening migration'; fail=1; }
[ -f supabase/functions/send-screenshot-request/index.ts ] || { echo 'FAIL: missing FCM Edge Function'; fail=1; }

check_absent 'MediaProjection|mediaProjection|ScreenshotProjectionManager|getConsentIntent|initializeContinuousCapture'
check_absent 'firebase\.auth|firebase\.firestore|firebase\.storage|firebase\.appcheck'
check_absent 'SERVICE_ROLE_KEY|FIREBASE_SERVICE_ACCOUNT_JSON'

if grep -RInE 'familyId = user\.id|val familyId = user\.id' app-parent core/data --include='*.kt' >/tmp/pc_verify_hit 2>/dev/null; then
  echo 'FAIL: user ID is still being used as family ID'
  cat /tmp/pc_verify_hit
  fail=1
fi

if grep -RIn 'debug.p12' . --exclude-dir=.git --exclude='verify_production.sh' >/tmp/pc_verify_hit 2>/dev/null; then
  echo 'FAIL: debug keystore reference remains'
  cat /tmp/pc_verify_hit
  fail=1
fi

if [ "$fail" -ne 0 ]; then
  exit 1
fi

echo 'PASS: production static checks passed.'
